import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;

public class registrationAWT extends Frame implements ActionListener {
    private TextField usernameField, passwordField;
    private Button registerButton, loginButton;
    private Map<String, String> users;

    public registrationAWT() {

        setLayout(new GridLayout(4, 2));

        users = new HashMap<>();

        Label usernameLabel = new Label("Username:");
        usernameField = new TextField(20);
        Label passwordLabel = new Label("Password:");
        passwordField = new TextField(20);
        passwordField.setEchoChar('*');

        registerButton = new Button("Register");
        registerButton.addActionListener(this);
        loginButton = new Button("Login");
        loginButton.addActionListener(this);

        add(usernameLabel);
        add(usernameField);
        add(passwordLabel);
        add(passwordField);
        add(registerButton);
        add(loginButton);

        setTitle("User Authentication App");
        setSize(300, 150);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == registerButton) {
            String username = usernameField.getText();
            String password = passwordField.getText();
            users.put(username, password);
            System.out.println("User registered: " + username);
        } else if (ae.getSource() == loginButton) {
            String username = usernameField.getText();
            String password = passwordField.getText();
            if (users.containsKey(username) && users.get(username).equals(password)) {
                System.out.println("Successfully logged in as: " + username);
            } else {
                System.out.println("Login failed. Invalid username or password.");
            }
        }
    }

    public static void main(String[] args) {
        new registrationAWT();
    }
}
