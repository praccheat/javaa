import java.awt.*;
import java.awt.event.*;

public class factorialAWT2 extends Frame implements ActionListener {
    private TextField inputField, resultField;
    private Button computeButton;

    public factorialAWT2() {
        setLayout(new FlowLayout());

        Label inputLabel = new Label("Enter an integer:");
        inputField = new TextField(10);

        Label resultLabel = new Label("Factorial:");
        resultField = new TextField(10);
        resultField.setEditable(false);

        computeButton = new Button("Compute");
        computeButton.addActionListener(this);

        add(inputLabel);
        add(inputField);
        add(computeButton);
        add(resultLabel);
        add(resultField);

        setTitle("Factorial Calculator");
        setSize(300, 150);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {

        int number = Integer.parseInt(inputField.getText());

        int factorial = 1;
        for (int i = 1; i <= number; i++) {
            factorial *= i;
        }

        resultField.setText(String.valueOf(factorial));
    }

    public static void main(String[] args) {
        new factorialAWT2();
    }
}
 
