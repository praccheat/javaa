import java.awt.*;
import java.awt.event.*;

class studentInfoAWT extends Frame implements ActionListener {
    Label l_name, l_rollno, l_class ;
    TextField t_name, t_rollno, t_class;
    Button submit;
    TextArea details;
    

    studentInfoAWT() {
        Frame f = new Frame();

        f.setTitle("student Form");
        f.setSize(300, 300);
        f.setLayout(new GridLayout(3,1));
        f.setVisible(true);

        l_name = new Label("Name:");
        l_rollno = new Label("Roll No:");
        l_class = new Label("Class:");

        t_name = new TextField();
        t_rollno = new TextField();
        t_class = new TextField();

        Panel p = new Panel();
        p.setLayout(new GridLayout(3,2));
        p.add(l_name);
        p.add(t_name);
        p.add(l_rollno);
        p.add(t_rollno);
        p.add(l_class);
        p.add(t_class);

        f.add(p);
        submit = new Button("Submit");
        f.add(submit);
        details = new TextArea("", 2, 10);
        details.setEditable(false);
        f.add(details);

        submit.addActionListener(this);

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submit) {
            
            String name = t_name.getText();
            String rollNo = t_rollno.getText();
            String cls = t_class.getText();
           
            String detail_s = "Name: " + name + "\nRoll No: " + rollNo + "\nClass: " + cls;
            details.setText(detail_s);
        }
    }

    public static void main(String[] args) {
        new studentInfoAWT();
    }
}
