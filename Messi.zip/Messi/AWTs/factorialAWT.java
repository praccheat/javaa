import java.awt.*;
import java.awt.event.*;

class factorialAWT implements ActionListener {
    Button b1;
    TextField t1;
    Label lb1, lb2;
    Frame f;

    factorialAWT() {
        f = new Frame("answer");
        f.setSize(350, 200);
        f.setVisible(true);
        f.setLayout(null);

        lb1 = new Label("Factorial result:");
        lb1.setBounds(50, 50, 100, 30);

        t1 = new TextField();
        t1.setBounds(200, 50, 100, 30);

        b1 = new Button("Compute");
        b1.setBounds(130, 150, 100, 30);
        b1.addActionListener(this);

        lb2 = new Label("Factorial result:");
        lb2.setBounds(100, 100, 100, 30);

        f.add(lb1);
        f.add(t1);
        f.add(lb2);
        f.add(b1);

        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        });   
    }

    public void actionPerformed(ActionEvent e) {
        int n = Integer.parseInt(t1.getText());
        int factorial = 1;
        if (e.getSource().equals(b1)) {
            for (int i = 1; i <= n; i++) {
                factorial *= i;
            }
            lb2.setText("Factorial is: " + factorial);
        }
    }

    public static void main(String args[]) {
        new factorialAWT();
    }
}
