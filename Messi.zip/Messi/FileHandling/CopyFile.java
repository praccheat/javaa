import java.io.*;    

public class CopyFile {    
    public static void main(String[] args) throws IOException
    {  
        FileInputStream fis = new FileInputStream("abc.txt");  
        FileOutputStream fos = new FileOutputStream("xyz.txt");  
    
        try {  
            int i;  
            while ((i = fis.read()) != -1) {  
                fos.write(i);  
            } 
            fis.close(); 
            fos.close();
            System.out.println("File Copied");
        }catch(Exception e) {  
            System.out.println("Error Found: "+e.getMessage());  
        }  
    
    }  
}  